import time

state = "站立中..."
print("站立中...")

def walk():
	global state
	state = "步行中..."
	print("步行中...")
	time.sleep(0.1)

def stand():
	global state
	state = "站立中..."
	print("站立中...")
	time.sleep(0.1)

def update():
	if state == "站立中...":
		walk()
	if state == "步行中...":
		stand()

while(True):
	update()

	
	
	










