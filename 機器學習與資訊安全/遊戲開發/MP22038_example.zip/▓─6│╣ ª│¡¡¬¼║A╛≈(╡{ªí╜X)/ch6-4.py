import time

state = "右腳前_左腳後"

def Leftwalk():
	global state
	print("右腳前_左腳後")
	state = "左腳前_右腳後"
	time.sleep(0.9)

def Rightwalk():
	global state
	print("左腳前_右腳後")
	state = "右腳前_左腳後"
	time.sleep(0.9)

def RightTurnwalk():
	global state
	print("左腳前_右腳後")
	state = "向右轉"
	time.sleep(0.9)

def Turnright():
	global state
	print("向右轉")
	state = "左腳前_右腳後"
	time.sleep(0.9)

def update():
	if state == "右腳前_左腳後":
		Leftwalk()
	if state == "左腳前_右腳後":
		Rightwalk()

def update2():
	if state == "右腳前_左腳後":
		Leftwalk()
	if state == "左腳前_右腳後":
		RightTurnwalk()
	if state == "向右轉":
		Turnright()

update()

while(True):
	update2()




	

	
	
	










