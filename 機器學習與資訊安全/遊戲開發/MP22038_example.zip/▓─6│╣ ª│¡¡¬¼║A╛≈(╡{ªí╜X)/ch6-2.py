import time

state = "右腳前_左腳後"

def Leftwalk():
	global state
	print("右腳前_左腳後")
	state = "左腳前_右腳後"
	time.sleep(0.9)

def Rightwalk():
	global state
	print("左腳前_右腳後")
	state = "右腳前_左腳後"
	time.sleep(0.9)

def update():
	if state == "右腳前_左腳後":
		Leftwalk()
	if state == "左腳前_右腳後":
		Rightwalk()

while(True):
	update()


	
	
	










