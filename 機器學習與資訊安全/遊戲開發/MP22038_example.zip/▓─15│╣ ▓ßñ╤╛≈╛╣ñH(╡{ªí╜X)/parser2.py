import nltk
from nltk import Tree
from nltk.draw import TreeView

grammar = nltk.CFG.fromstring("""
S -> NP VP
PP -> P NP
NP -> Det N | NP PP | N 
VP -> V NP | VP PP
Det -> 'an' | 'a' | 'The' | 'the'
N -> 'elephant' | 'room' | 'kitchen' | 'chicken' | 'monkey'| 'table'| 'banana'|'I'
V -> 'kill' | 'eat' | 'eats'
P -> 'in' | 'on'
 """)

#sent1 = ['I', 'kill', 'a', 'chicken', 'in', 'a', 'kitchen']

sent1 = ['The', 'monkey', 'eats', 'a', 'banana', 'on', 'a', 'table']

parser = nltk.ChartParser(grammar)


treegraph = []

filename1 = 'g1.ps'
filename2 = 'g2.ps'

t0_height = 0
t1_height = 0

for t in parser.parse(sent1):
    print(t, end='\n')
    if t0_height == 0:
        t0_height = t.height()
        print("結構(1)高度:",t.height(), end='\n\n')
    else:
        t1_height = t.height()
        print("結構(2)高度:",t.height(), end='\n\n')

    
for tree in parser.parse(sent1):
    treegraph.append(tree)
    
if t0_height < t1_height:
    print("聊天機器人選擇下列文法結構(1):", end='\n\n')
    print(treegraph[0], end='\n\n')
    print("因為上列的文法節點層數較小！")
else:
    print("聊天機器人選擇下列文法結構(2):", end='\n\n')
    print(treegraph[1], end='\n\n')
    print("因為上列的文法節點層數較小！")
     
for a in treegraph:
    trees = [Tree.fromstring(str(a))]
    if filename1 != '':
        TreeView(*trees)._cframe.print_to_file(filename1)
        filename1 = ''
    else:
        TreeView(*trees)._cframe.print_to_file(filename2)      

    



    
    
    
    