from nltk.tokenize import word_tokenize
import random

sentence = input("請輸入一個句子：")

keywords = ("喜歡", "故事", "自己", "不同的")

responses = ["為什麼？", "故事精彩嗎？", "只有你自己嗎？", "有何不同呢？"]

def check_for_greeting():
    for word in word_tokenize(sentence):
        if word in keywords:
            return random.choice(responses)

print(check_for_greeting())


