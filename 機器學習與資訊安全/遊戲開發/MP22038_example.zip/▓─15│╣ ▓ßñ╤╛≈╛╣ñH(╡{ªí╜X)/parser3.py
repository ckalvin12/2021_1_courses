import nltk
from nltk import Tree
from nltk.draw import TreeView

grammar = nltk.CFG.fromstring("""
S -> NP VP
PP -> P NP | PP PP 
NP -> Det N | NP PP | N 
VP -> V NP | VP PP 
Det -> 'an' | 'a' | 'The' | 'the'
N -> 'elephant' | 'room' | 'kitchen' | 'chicken' | 'monkey'| 'table'| 'banana'|'I'
V -> 'kill' | 'eat' | 'eats'
P -> 'in' | 'on'
 """)


p = 0
k = []
k2 = 0 
f = ""

print("聊天機器人說：", end='')
s2 = input("請輸入一個英文句子＞")
#   The monkey eats a banana on a table
#   The monkey eats a banana on a table in a room

for r in s2.split():
    k.append(r)
print(k) #['The', 'monkey', 'eat', 'a', 'banana', 'on', 'a', 'table']


parser = nltk.ChartParser(grammar)

treegraph = []
    
for tree in parser.parse(k):
    treegraph.append(tree)
 
tree_height = []


for t in parser.parse(k):
    print(t, end='\n') 
    tree_height.append(t.height())
    print("結構",p,"高度:",t.height(), end='\n\n')
    p = p+1

for a in treegraph:
    trees = [Tree.fromstring(str(a))]
    f = "h"+str(k2)+".ps"
    TreeView(*trees)._cframe.print_to_file(f)
    k2 = k2 + 1

v = ''

q = []

q2 = []

pos_list = []

mm = min(tree_height)

def test(string_list):    
    for i in range(len(string_list)):
        if string_list[i] == mm:
            pos_list.append(i)
  

print("最小高度的文法結構為: ")
test(tree_height)
print(pos_list)
print()

goodtree = []

for i in pos_list:
    print(treegraph[i])
    goodtree.append(treegraph[i])
    print()
 
for t in goodtree:   
        print("顯示所有的名詞片語樹: ")
        for i in t.subtrees(filter=lambda x: x.label() == 'NP'):
            print(i)
            parse_string = ' '.join([w for w in i.leaves()])
            q.append(parse_string)
        print("顯示所有的介系詞片語樹: ")
        for i in t.subtrees(filter=lambda x: x.label() == 'PP'):            
            print(i)
            parse_string2 = ' '.join([w for w in i.leaves()])
            q2.append(parse_string2)
        
print("顯示所有的名詞片語: ")
for u in q:
    print(u)
    
print("顯示所有的介系詞片語: ")
for u in q2:
    print(u)

for pp in q2:
    v = q[0] + " is " + pp
    print("聊天機器人回答:",v,".")



     




    
    
    
    