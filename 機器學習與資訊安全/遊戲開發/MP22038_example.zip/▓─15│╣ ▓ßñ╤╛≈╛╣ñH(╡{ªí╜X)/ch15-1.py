import random
import time

greetings = ['嗨', '您好', '你記得我嗎']

question = ['什麼是聊天機器人？','你知道人工智慧嗎？', '機器人會自我學習嗎？']
responses = ['這是一個很深奧的學問。','我想想看...', '機器人有人工智慧，當然會學習及聊天。']

while True:

    for a in range(2):
        print(random.choice(greetings))
        time.sleep(2)

    print(random.choice(question))
    time.sleep(2)
    print(random.choice(responses))
    time.sleep(2)

