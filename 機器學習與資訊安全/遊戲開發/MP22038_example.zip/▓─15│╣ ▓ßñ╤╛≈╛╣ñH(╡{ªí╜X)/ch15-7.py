from nltk.tokenize import word_tokenize
import random

#sentence = "我 喜歡 談論我 自己 與眾 不同的 奮鬥 故事。"
#sentence = "請問要 如何 讓 機器人 的 智慧 跟人類一樣 聰明？"

storykeywords = ("喜歡", "故事", "自己", "不同的")
storyresponses = ["為什麼？", "故事精彩嗎？", "只有你自己嗎？", "有何不同呢？"]

techkeywords = ("如何", "機器人", "智慧 ", "聰明")
techresponses = ["你自己想過了沒有。", "不如說是跟電腦比較。", "你聰明嗎？"]

def chat():
    sentence = input("請輸入一個句子：")
    for word in word_tokenize(sentence):
        if word in storykeywords:
            return random.choice(storyresponses)
        elif word in techkeywords:
            return random.choice(techresponses)

while True:
    print(chat())



