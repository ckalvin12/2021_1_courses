import random
import time

greetings = ['嗨', '您好', '你記得我嗎']

question = ['什麼是聊天機器人？','你知道人工智慧嗎？', '機器人會自我學習嗎？']
responses = ['這是一個很深奧的學問。','我想想看...', '機器人有人工智慧，當然會學習及聊天。']
robot = ["機器人1:","機器人2:"]
b = 1
robotman = robot[0]

while True:
    for a in range(2):
        print(robotman,random.choice(greetings))
        b = b * -1
        if b > 0:
            robotman = robot[0]
        else:
            robotman = robot[1]
        time.sleep(2)

    print(robot[0],":",random.choice(question))
    time.sleep(2)
    print(robot[1],":",random.choice(responses))
    time.sleep(2)


