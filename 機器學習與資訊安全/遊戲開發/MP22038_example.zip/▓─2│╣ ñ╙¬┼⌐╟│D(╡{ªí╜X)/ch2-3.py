
def wingup():
	print("X    X")
	print(" X  X")
	print("  O")
	

def wingdown():
	print("  O")
	print(" X  X")
	print("X    X")
	
while(True):
	wingup()
	wingdown()
	
	
	









