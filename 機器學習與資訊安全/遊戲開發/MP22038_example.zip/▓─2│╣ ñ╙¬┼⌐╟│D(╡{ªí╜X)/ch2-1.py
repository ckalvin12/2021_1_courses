
print("X    X")
print(" X  X")
print("  O")








