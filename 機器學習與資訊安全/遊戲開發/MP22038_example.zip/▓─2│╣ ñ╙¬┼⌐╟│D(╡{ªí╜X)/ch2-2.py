
print("  O")
print(" X  X")
print("X    X")









