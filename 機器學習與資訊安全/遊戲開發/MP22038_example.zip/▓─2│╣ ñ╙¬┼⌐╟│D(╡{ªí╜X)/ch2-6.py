from random import choice

coordinate_numbersX = range(1,6)
coordinate_numbersY = range(1,6)

space_snake_coordinateX = choice(coordinate_numbersX)
space_snake_coordinateY = choice(coordinate_numbersY)

big_bird_coordinateX = choice(coordinate_numbersX)
big_bird_coordinateY = choice(coordinate_numbersY)

while big_bird_coordinateX == space_snake_coordinateX and big_bird_coordinateY == space_snake_coordinateY:
		new_coordinateX = choice(coordinate_numbersX)
		new_coordinateY = choice(coordinate_numbersY)
		big_bird_coordinateX = new_coordinateX
		big_bird_coordinateY = new_coordinateY

print ("人工巨鳥正在尋找太空怪蛇。")
print ("X軸總共有", len(coordinate_numbersX), "個座標位置。")
print ("Y軸總共有", len(coordinate_numbersY), "個座標位置。")

while True:
    print ("人工巨鳥目前所在位置:", big_bird_coordinateX, "<=>", big_bird_coordinateY)
    #print ("太空怪蛇目前所在位置:", space_snake_coordinateX, "<=>", space_snake_coordinateY)
  
    if ((big_bird_coordinateX == space_snake_coordinateX - 1 and big_bird_coordinateY == space_snake_coordinateY - 1) or
        (big_bird_coordinateY == space_snake_coordinateY + 1 and big_bird_coordinateY == space_snake_coordinateY + 1)):
        print ("正察覺到太空怪蛇在附近...")

    print ("請輸入人工巨鳥要去的X軸位置！")
    big_bird_coordinateX = int(input(">>>"))
    print ("請輸入人工巨鳥要去的Y軸位置！")
    big_bird_coordinateY = int(input(">>>"))
	
    if big_bird_coordinateX == space_snake_coordinateX and big_bird_coordinateY == space_snake_coordinateY :
            print ("抓到太空怪蛇了!")
            print("太空怪蛇被吃掉了!")
            print("現在您可以無憂無慮地駕駛太空船了!")
            break

