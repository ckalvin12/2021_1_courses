from random import choice

energy = 5
coordinate_numbers = range(1,11)
space_snake_coordinate = choice(coordinate_numbers)
big_bird_coordinate = choice(coordinate_numbers)
energy_fruit_coordinate = choice(coordinate_numbers)

while big_bird_coordinate == space_snake_coordinate:
		new_coordinate = choice(coordinate_numbers)
		big_bird_coordinate = new_coordinate		
		
while big_bird_coordinate == energy_fruit_coordinate:
		new_coordinate = choice(coordinate_numbers)
		big_bird_coordinate = new_coordinate		

print ("人工巨鳥正在尋找太空怪蛇。")
print ("總共有", len(coordinate_numbers), "個座標位置。")

while True:
    print ("人工巨鳥目前所在位置:", big_bird_coordinate)
    #print("太空怪蛇目前所在位置:", space_snake_coordinate)
    #print("大力果目前所在位置:", energy_fruit_coordinate)

    if (big_bird_coordinate == energy_fruit_coordinate - 1 or big_bird_coordinate == energy_fruit_coordinate + 1):
            print ("正察覺到大力果在附近...")
    if (big_bird_coordinate == space_snake_coordinate - 1 or big_bird_coordinate == space_snake_coordinate + 1):
        print("正察覺到太空怪蛇在附近...")
    if (big_bird_coordinate == space_snake_coordinate - 2 or big_bird_coordinate == space_snake_coordinate + 2):
            print ("正察覺到太空怪蛇在較遠的附近...")

    print ("請輸入人工巨鳥要去的位置！")
    big_bird_coordinate = input(">>>")
    big_bird_coordinate = int(big_bird_coordinate)
	
    if big_bird_coordinate == energy_fruit_coordinate:
            print ("已吃下大力果!")
            energy = 10
           
    if big_bird_coordinate == space_snake_coordinate and energy == 10:
            print ("抓到太空怪蛇了!")
            print("太空怪蛇被吃掉了!")
            print("現在您可以無憂無慮地駕駛太空船了!")
            break
    if big_bird_coordinate == space_snake_coordinate and energy < 10:
            print ("抓到太空怪蛇了!")
            print("但人工巨鳥被太空怪蛇吃掉了!")
            print("現在您也被太空怪蛇吃掉了!")
            break
