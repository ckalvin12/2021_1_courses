def message():
   print('訊息傳送中…')
   print('我來自火星。')
   print('您們找不到火星人的原因是：')
   print('我們生存在5維空間裡。')

message()
