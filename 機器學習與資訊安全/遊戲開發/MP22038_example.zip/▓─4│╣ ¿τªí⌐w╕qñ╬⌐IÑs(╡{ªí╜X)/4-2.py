def main():
    print('訊息傳送中…')
    message()
    print('其實火星人沒有身體，只是由一堆程式碼組成。哈哈！')

def message():
    print('我是火星人。')
    print('用量子電腦，就會發現我們。')

main()
