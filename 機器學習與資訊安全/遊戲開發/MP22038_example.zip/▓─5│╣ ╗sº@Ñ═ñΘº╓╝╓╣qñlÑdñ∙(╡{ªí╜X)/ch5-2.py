
var1 = "祝您生日快樂，心願達成！"

for r in range(2):
	for a in var1:
		print(a)

for x in range(60000000):
  pass
  
print("來自電腦的")
print("            祝福！")


  
 
