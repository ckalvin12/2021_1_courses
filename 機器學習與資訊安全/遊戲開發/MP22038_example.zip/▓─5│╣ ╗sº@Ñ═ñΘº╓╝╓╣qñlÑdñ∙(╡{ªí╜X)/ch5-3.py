
var1 = "祝您生日快樂，心願達成！"

counts = ["第一次","第二次","第三次"]

for r in counts:
	for a in var1:
		print(a)

for x in range(60000000):
  pass
  
print("來自電腦的")
print("            祝福！")


  
 
