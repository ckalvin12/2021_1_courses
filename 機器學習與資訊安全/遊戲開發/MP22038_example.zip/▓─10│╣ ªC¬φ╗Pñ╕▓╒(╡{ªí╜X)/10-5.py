my_list = [1, 2, 3, 4, 5]
print('原次序:', my_list)
my_list.reverse( )
print('次序反向:', my_list)