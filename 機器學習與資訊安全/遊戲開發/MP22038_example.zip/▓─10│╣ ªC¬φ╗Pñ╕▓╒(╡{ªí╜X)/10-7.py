input = '陳,小明,2000,5,1'
tokens = input.split(',')
lastName = tokens[0]
firstName = tokens[1]
birthdate = (tokens[2], tokens[3], tokens[4])
print('Hi ' + lastName + firstName)
print(birthdate[0])
birthdate[1] = 12
print(birthdate[1])