animal = ['dog','cat','pig']
animal.append('bat')
print(animal)
