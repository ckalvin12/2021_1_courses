my_list = ['a', 'b', 'c', 'd','e']
print('插入前:', my_list)
my_list.insert(3,'d2')
print('插入後:', my_list)