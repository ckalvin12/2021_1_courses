list = ['x-1', 'x-2', 'x-3']
print( " list length : ", len(list))
