food = ['Pizza', 'Bread', 'Candy', 'Bread']
print('Here are the items in the food list:')
print(food)

food.remove('Bread')
print('Here is the revised list:')
print(food)