inventory = ['weapon','car','submarine','food']
print(inventory [0:3])