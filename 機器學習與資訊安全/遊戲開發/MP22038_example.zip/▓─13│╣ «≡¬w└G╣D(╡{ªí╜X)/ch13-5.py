from random import choice

bubble_numbers = range(0, 5)
bubbles = []
for i in bubble_numbers:
    bubbles.append([])
print(bubbles)

prelink = None

for i in bubble_numbers:
    for j in range(2):
        link = choice(bubble_numbers)
        while link == prelink:
            link = choice(bubble_numbers)
        bubbles[i].append(link)
        prelink = link
		
a = len(bubbles)
for b in range(a):
    print("產生氣泡", b)
    print(b,bubbles[b])

monster = choice(bubble_numbers)
man = choice(bubble_numbers)
knife = choice(bubble_numbers)

while man == monster:
    man = choice(bubble_numbers)

while knife == monster:
    knife = choice(bubble_numbers)

while knife == man:
    knife = choice(bubble_numbers)

print("怪獸位置:", monster)
print("你的位置:", man)
print("神刀位置:", knife)

pickup = False

def testknife():
    global pickup
    pickup = True

while True:
    print("你在氣泡"+str(man)+"裡面。")
    print("你可通往的氣泡位置是:", bubbles[man])

    if monster in bubbles[man]:
        print("小心，怪獸在附近！")

    if knife in bubbles[man] and pickup == False: #若神刀已拿，則不執行
        print("趕快去拿神刀！")

    newposition = input("你要去的氣泡新位置為：")
    if (int(newposition) not in bubbles[man]):
        print("此氣泡位置",newposition,"無法到達。")
        continue

    man = int(newposition)

    if man == knife:
        print("你已拾取神刀！")
        print("怪獸將完蛋了!")
        testknife()       
	
    if man == monster and pickup == False:
        print("你居然跑到怪獸藏匿的氣泡位置！")
        print("怪獸把你吃掉了!")
        break

    if man == monster and pickup == True:
        print("你用神刀把怪獸殺死了！")
        break

