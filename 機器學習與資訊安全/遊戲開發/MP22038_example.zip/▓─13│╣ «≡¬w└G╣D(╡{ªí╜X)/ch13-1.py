from random import choice

bubble_numbers = range(0, 5)
bubbles = []
for i in bubble_numbers:
    bubbles.append([])
print(bubbles)

prelink = None

for i in bubble_numbers:
    for j in range(2):
        link = choice(bubble_numbers)
        while link == prelink:
            link = choice(bubble_numbers)
        bubbles[i].append(link)
        prelink = link
		
a = len(bubbles)
for b in range(a):
    print("產生氣泡", b)
    print(b,bubbles[b])