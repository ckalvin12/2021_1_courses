from random import choice

def instruction2():
	print("請在鍵盤上，按下任何一個按鍵來繼續玩本程式遊戲。")

def instruction():
	print("您即將啟程前往需要醫療用品的星球。")
	print("這次旅行的距離很遙遠，")
	print("大部分時間您都將處於深度睡眠狀態。")
	print("但是在此之前，你必須為旅程安排妥當。")
	print("電腦會詢問你想分配多少能量給引擎、維生系統和防護罩。")
	print("當您醒來時，電腦將提供旅途中發生的情況報告。")
	print("您必須成功降落到這個星球上來提供醫療用品。")
	instruction2()
	
def showlist():	
	D = choice(range(100,800))
	E = choice(range(400,410))
	T = int(D/E + 100)
	decoration_line = "<@@@@@@@@@@@@@@@@@@@@@@@>"
	print(decoration_line)
	print("這星球距離地球"+str(D)+"光年。")
	print("你總共有"+str(E)+"個單位的能量")
	print("及剩下"+str(T)+"天的時間。")
	print(decoration_line,"\n")

print("太空救援","\n")
i = input("需要顯示任務說明嗎？(y 或 n) ")
if i == "y":
	instruction()
	a = input()
	while a == "":
		instruction2()
		a = input("不可按Enter鍵！： ")

myprofile = {'武器(神刀)':"刀",'武器(霹靂核彈槍)':"手槍"}
eneprofile = {'外星武器(雷射光束刀)':"刀",'外星武器(雷射槍)':"手槍"}

a,b = choice(list(myprofile.items()))

c,d = choice(list(eneprofile.items()))
#print(a,b)
#print(c,d)
if b == "刀" and d == "手槍":
	print("外星人贏!")
	print("外星人使用:",c)
	print("我使用:",a)
elif b == "手槍" and d == "刀":
	print("我贏!")
	print("外星人使用:",c)
	print("我使用:",a)
	showlist()
else:
	print("平手!")
	print("外星人使用:",c)
	print("我使用:",a)	



	
	




		


 