from random import choice
import math 
import random

def instruction2():
	print("請在鍵盤上，按下任何一個按鍵來繼續玩本程式遊戲。")

def instruction():
	print("您即將啟程前往需要醫療用品的星球。")
	print("這次旅行的距離很遙遠，")
	print("大部分時間您都將處於深度睡眠狀態。")
	print("但是在此之前，你必須為旅程安排妥當。")
	print("電腦會詢問你想分配多少能量給引擎、維生系統和防護罩。")
	print("當您醒來時，電腦將提供旅途中發生的情況報告。")
	print("您必須成功降落到這個星球上來提供醫療用品。")
	instruction2()
	
D = 0
E = 0
T = 0
	
def showlist():	
	global D 
	D = choice(range(100,800))
	global E
	E = choice(range(4000,4100))
	global T
	T = int(D/E + 100)
	decoration_line = "<@@@@@@@@@@@@@@@@@@@@@@@>"
	print(decoration_line)
	print("這星球距離地球"+str(D)+"光年。")
	print("你總共有"+str(E)+"個單位的能量")
	print("及剩下"+str(T)+"天的時間。")
	print(decoration_line,"\n")

print("太空救援","\n")
i = input("需要顯示任務說明嗎？(y 或 n) ")
if i == "y":
	instruction()
	a = input()
	while a == "":
		instruction2()
		a = input("不可按Enter鍵！： ")

myprofile = {'武器1':"刀",'武器2':"手槍"}
eneprofile = {'外星武器1':"刀",'外星武器2':"手槍"}

a,b = choice(list(myprofile.items()))

c,d = choice(list(eneprofile.items()))

con = False

if b == "刀" and d == "手槍":
	print("外星人贏!")	
elif b == "手槍" and d == "刀":
	print("我贏!")
	showlist()
	con = True
else:
	print("平手!")
		

E2 = 0
L = 0
S = 0
V = 0
T1 = 0

def distributingE():
	global E2
	E2 = int(input("想分配多少能量給引擎？"))
	print(E2)
	global L
	L = int(input("想分配多少能量給維生系統？"))
	global S
	S = int(input("想分配多少能量給防護罩？"))
	
def fifty():
    return random.randrange(2)
	
def report():
	if S < 0:
		print("防護罩被催毀。")
	if L < 0:
		print("維生系統耗盡。")
	if V < 0:
		print("引擎停止運轉。")
	if T1 > T:
		print("您飛得太久才到達。")
		
def die():
	print("流星雨撞擊您的太空船。")	
	print("維生系統受到宇宙射線攻擊。")	
	print("引擎過熱故障。")	
	print("電腦當機導致延遲。")	

def damage():
	global S
	S = S - choice(range(0,8))
	global L
	L = L - choice(range(10,15))
	global V
	V = V - choice(range(500,800)) 
	global T1
	T1 = T1 + choice(range(500,800))

if con == True:
	distributingE()
	
while E2+L+S > E and con == True:
	distributingE()

def con2():
	if L > 0 and V > 0:
		print("維生系統沒有耗盡。")
		print("引擎仍可運轉。")
		return True
	
if con == True:	
		X = E-E2-L-S	
		V = int(math.sqrt(E2))	
		T1 = int(D/V)
		print("您的飛行速率是:",V)
		print("預計有",T1,"天可到達")
		damage()
		if fifty() == 1:
			report()
			if con2 == True:
				print("您可以將醫療用品拋射至星球的安全地方。")
		else:
			die()


		



		


 