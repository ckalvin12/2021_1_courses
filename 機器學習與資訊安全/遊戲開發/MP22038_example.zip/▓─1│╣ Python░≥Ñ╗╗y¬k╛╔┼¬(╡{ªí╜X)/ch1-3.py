
name = input('請輸入您的武器名稱？')
kill = int(input('您的武器殺傷力為何？'))
name2 = input('請輸入敵人的武器名稱？')
kill2 = int(input('敵人武器殺傷力為何？'))

print('武器殺傷力資料分析:')
print('----------------------------------------------')
print('您的武器名稱：', name)
print('您的武器殺傷力：', kill)
print('----------------------------------------------')
print('敵人的武器名稱：', name)
print('敵人的武器殺傷力：', kill)

compare = kill-kill2

print('您的殺傷力減去敵人殺傷力為：', compare)

