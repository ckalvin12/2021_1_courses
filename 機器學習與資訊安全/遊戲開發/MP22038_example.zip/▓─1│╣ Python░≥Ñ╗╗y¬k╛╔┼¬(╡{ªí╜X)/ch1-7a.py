def check_energy(shooting_time):
    if (shooting_time >= 10):
       print("您沒有電力了！")
    else:
       print("您還有電力了！")

check_energy(5)


