print('數值','平方值')
print('--------------')

for number in range(1, 11,1):
    square = number**2
    print(number,'  ', square)





