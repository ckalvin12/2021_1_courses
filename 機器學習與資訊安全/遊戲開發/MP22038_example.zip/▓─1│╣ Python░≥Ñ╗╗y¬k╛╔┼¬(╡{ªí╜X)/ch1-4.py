
HIGH_SCORE = 90
test1 = int(input('輸入第一次期中考試成績: '))
test2 = int(input('輸入第二次期中考試成績: '))
test3 = int(input('輸入第三次期中考試成績: '))

average = (test1 + test2 + test3) / 3

if average >= HIGH_SCORE:
    print('恭喜學業平均成績超過90分！')
else:
    print('請再接再勵！')

