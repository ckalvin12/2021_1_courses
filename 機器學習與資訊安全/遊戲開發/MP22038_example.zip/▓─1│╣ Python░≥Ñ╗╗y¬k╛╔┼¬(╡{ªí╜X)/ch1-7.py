def main():
    startup_message()
    input('按下Enter鍵，以顯示步驟 1')
    step1()
    input('按下Enter鍵，以顯示步驟 2')
    step2()

def startup_message():
    print('本程式教您如何修復太空船。')
    print('打開太空船的後門。')
    print('接下來，需要2個步驟完成修復。')
    print()

def step1():
    print('步驟 1: 拔掉前面的把手。')
    print('將把手放置於一個平坦的地方。')
    print()

def step2():
    print('步驟 2: 從備用動力板上，')
    print('卸下2個螺絲。')
    print()

main()





