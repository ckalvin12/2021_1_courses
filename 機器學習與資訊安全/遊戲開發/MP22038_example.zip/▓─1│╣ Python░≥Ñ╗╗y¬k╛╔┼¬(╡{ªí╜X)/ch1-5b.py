
MAX_TEMP = 100
temperature = float(input("輸入加熱溫度： "))

while temperature > MAX_TEMP:
    print('溫度太高。')
    print('請關閉加熱器。')
    print('3分鐘後，再輸入一次加熱溫度。')
    temperature = float(input('請再輸入一次加熱溫度： '))

print('這個加熱溫度可以接受。')




