from random import choice

def success():
	print("成功起飛！")
	
def delay():
	print("故障安全機制將開始運作")
	print("外星人將抓到你！")
	
def fail():
	print("起飛失敗")
	print("外星人將抓到你！")
		
def hit():
	print("由於衝力太大，")
	print("你撞到另一台太空飛船！")

print("星艦起飛")
G = choice(range(1,21))
W = choice(range(1,41))
R=G*W

print(R)

print("重力 = "+str(G))

c = 0

for c in range(3):
	F = input("輸入起飛所需的衝力: ")
	if int(F) > R:
		print("太大")
		if c == 2:
			delay()
		elif int(F) > R+10:
			hit()
			break
	elif int(F) < R:
		print("太小")
		if c == 2:
			fail()
	elif int(F) == R:
		success()
		








	


