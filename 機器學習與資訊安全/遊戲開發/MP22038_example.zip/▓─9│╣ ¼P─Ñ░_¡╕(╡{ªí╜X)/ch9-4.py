from random import choice
import time

def success():
	print("成功起飛！")
	print('''
	                     
       _.---._          
    .'  O  O  '.     
 _.-~===========~-._ 
(__________________) 
     \_______/       
         o           
         o           
         0           
	''')
	
def delay():
	print("故障安全機制將開始運作")
	print("外星人將抓到你！")
	
def fail():
	print("起飛失敗")
	print("外星人將抓到你！")
		
def hit():
	print("由於衝力太大...")
	time.sleep(2)
	print("你撞到另一台太空飛船！")
	
def alien():
	print("由於衝力太小...")
	time.sleep(2)
	print("一個躲在岩石後面的")	
	time.sleep(2)
	print("外星人突然用雷射槍瞄準你的飛船！")
	time.sleep(2)
	print("你使飛船的輪子往右移。")
	
def aim():
	print("外星人有瞄準到你的飛船！")
	time.sleep(2)
	print("外星人按下射擊按鈕。")	
	time.sleep(2)
	print("你的飛船是否會爆炸呢？")	
	explosion = input("輸入 y 代表會爆炸，輸入 n 代表不會爆炸: ")
	time.sleep(2)
	return explosion

print("星艦起飛")
G = choice(range(1,21))
W = choice(range(1,41))
R=G*W

#print(R)

print("重力 = "+str(G))

c = 0

for c in range(3):
	F = input("輸入起飛所需的衝力: ")
	if int(F) > R:
		print("太大")
		if c == 2:
			delay()
		elif int(F) > R+10:
			hit()
			break
	elif int(F) < R:
		print("太小")
		if c == 2:
			fail()
		else:
			alien()
			p = aim()
			if p == "y":
				print("你被炸傷了！")
			else:
				print("你的飛船有防護罩，雷射光無法窗透您的飛船。")				
	elif int(F) == R:
		success()
		break
		








	


