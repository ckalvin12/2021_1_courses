from nltk.chat.util import Chat, reflections
import re
import random
import webbrowser

class BotChat(Chat):   

    def __init__(self, pairs, reflections={}):

        self._pairs = [(re.compile(q, re.IGNORECASE),a, f) for (q, a, f) in pairs]
        self._reflections = reflections
        self._regex = self._compile_reflections()
        self.robot = ["邪惡飛龍說:","聊天機器人說:"]              

    def respond(self, str):

        for (pattern, response, function) in self._pairs:
            matched = pattern.match(str)

            if matched:

                resp = random.choice(response)
                resp = self._wildcards(resp, matched)

                if resp[-2:] == '?.':
                    resp = resp[:-2] + '.'
                if resp[-2:] == '??':
                    resp = resp[:-2] + '?'

                if function: 
                    function(matched)

                return resp
            
    def converse(self, quit="離開。"):
        user_input = ""
        while user_input != quit:
            user_input = quit
            try:
                user_input = input(self.robot[0])
            except EOFError:
                print(user_input)
            if user_input:
                while user_input[-1] in "!.":
                    user_input = user_input[:-1]
                print(self.robot[1]+str(self.respond(user_input)))

def openthing(match):

    groups = match.groups()
    if groups:
        if groups[0] == 'google':
            webbrowser.open('https://www.google.com')
            print("已經開啟google網頁。")
        elif groups[0] == 'wiki':
            webbrowser.open('https://zh.wikipedia.org/wiki/Wiki')
        else:
            print('"{}"是什麼?'.format(groups[0]))
    else:
        print("不懂你的意思。")

nodrinking_cause = ["酒太貴","傷身體","沒時間睡覺"]

def drink(match):

    groups = match.groups()
    if groups:
        if groups[0] == "酒":
            print(Talk.robot[1])
            print("-"*10)
            print("我以前喜歡喝酒，但是現在不喝了。")
            print("我不喝酒的原因是：",random.choice(nodrinking_cause),"。")
            print("-"*10)
        elif groups[0] == "海水":
            print("海水不能喝。")
            print("空氣、食物和，是生命活動中不可缺少的物質。")
            print("單說水，一個人如果沒有水，4天左右就會進入昏迷狀態。")
            print("8-12天就會死亡。如果有水而沒有食物，生命往往可以維持21天左右。")
            print("海洋水最多，為什麼不能來維持生命呢?。")           
        else:
             print('"{}"是什麼?'.format(groups[0]))
    else:
        print("不懂你的意思。")
 
reasoning = ["懂","不懂"]
       
def detail(match):

    groups = match.groups()
    if groups:
        if groups[0] == "原因":
            print("飲用海水愈多，人體脫水愈快，人便愈渴了。如果飲用海水太多")
            print("腎臟便不能完成使人體內部鹽分保持平衡的任務，")
            print("腎臟便不能完成使人體內部鹽分保持平衡的任務於是人體內部的")
            print("物理化學平衡便會受到破壞，進一步導致中樞神經系統(腦)的傷害。")

            u = input("請問你懂了嗎？")
#            print(random.choice(reasoning))
            if u == reasoning[1]:
                print("請上網查google，你會知道更多。")
        elif groups[1] == '缺點' and groups[0] == '酒':
            print("喝酒的"+groups[1]+"是:")
            print("刺激胃黏膜，引起慢性胃炎、胃潰瘍、十二指腸潰瘍。")
            print("初期輕微胸痛、心律不整。")
            print("有精神方面焦慮、抑鬱等症狀。")
            print("慢性酒精中毒會損傷視神經，視力會逐漸降低。")
        else:
            print('"{}"是什麼?'.format(groups[0]))
    else:
        print("不懂你的意思。")


pairs = [

    ["請打開(.*)。", ["開啟完畢 ..."], openthing],
   
    ["你喝(.*)嗎？", ["這就是原因。"], drink],
    
    ["你繼續說明海水的(.*)。", ["這些原因夠詳細了吧。"], detail],
    
    ["你繼續說明(.*)或(.*)。", ["這些原因夠詳細了吧。"], detail],
    
    ["離開。", ["再見！"],None],
    
    ["(.*)", ["不懂你的意思。"],None],    
    
]

#pairs1 = [
#
#    ["請打開(.*)。", ["開啟完畢 ..."]],
#      
#    ["離開。", ["再見！"]],    
#]

print('\n'+"我是新型聊天機器人，請問什麼事？")
Talk = BotChat(pairs, reflections)
Talk.converse()
#Talk2 = Chat(pairs1, reflections)
#Talk2.converse()