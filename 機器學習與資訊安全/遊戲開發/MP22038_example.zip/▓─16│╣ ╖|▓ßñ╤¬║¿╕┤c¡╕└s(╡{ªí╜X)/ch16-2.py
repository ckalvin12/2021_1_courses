# 邪惡飛龍 與 你 交談

import random
import time

class Knife:
    def __init__(self):
        self.name = '刀子'
        
    def __str__(self):
        return self.name


question = ['什麼是聊天機器人？','你知道人工智慧嗎？', '機器人會自我學習嗎？']
responses = ['這是一個很深奧的學問。','我想想看...', '機器人有人工智慧，當然會學習及聊天。']

hp = 10
exp = 0

bag = [Knife()]
bag2 = []

for item in bag:
    bag2.append(str(item))

print("你今天要去深林旅遊。")
print("你將1樣東西放入背包裡，背包裡有下列東西：")
for item in bag2:
    print(str(item))
#..................................................

robot = ["你:","邪惡飛龍:"]

def converse():
    print("你現在開始跟飛龍交談：")
    while True:
        print(robot[0],random.choice(question))
        time.sleep(1)
        print(robot[1],random.choice(responses))
        time.sleep(1)
    
print("你在深林裡，遇到一隻邪惡飛龍。")   
event1 = input("按下k鍵，表示您想要從背包裡取出刀子。")

if event1 == ("k"): 
    if '刀子' in bag2: 
        print("您已經從背包裡取出刀子，邪惡飛龍被你嚇跑。")
        exp=exp + 3 
        hp=hp + 1
    else:
        print("您的背包裡沒有刀子，邪惡飛龍咬傷你了！")
        exp=exp + 3 
        hp=hp - 3      
else: 
    print("邪惡飛龍正飛向你....")
    time.sleep(1.0) 
    print("邪惡飛龍攻擊你。")
    time.sleep(2.0) #pause to add tension to game
    print("但你跟邪惡飛龍說好話，邪惡飛龍變成你的好朋友。")
    time.sleep(3.0) 
    print("邪惡飛龍現在願意幫助你走出深林。")
    exp=exp + 5    # exp points updated
    hp=hp - 3 
    time.sleep(2.0) 
    converse()
#.............................................







