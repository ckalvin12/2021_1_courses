import random
import time

class Knife:
    def __init__(self):
        self.name = '刀子'
        
    def __str__(self):
        return self.name

question = ['邪惡飛龍為什麼愛聽好話呢？','邪惡飛龍有智慧嗎？', '邪惡飛龍為何怕刀子呢？']
responses = ['這是一個很深奧的學問。','我想想看...', '邪惡飛龍是變形的機器人，當然有人工智慧。']

hp = 6
exp = 0

bag = [Knife(),Knife()]
bag2 = []

for item in bag:
    bag2.append(str(item))

print("你今天要去深林旅遊。")
print("你將2樣東西放入背包裡，背包裡有下列東西：")
for item in bag2:
    print(str(item))
#..................................................

robot = ["你說:","邪惡飛龍說:"]

tmp = ''

def converse():
    print("你現在開始跟飛龍交談：")
    counter = 3
    while counter > 0:
        print(robot[0],random.choice(question))
        time.sleep(1)
        tmp = random.choice(responses)
        print(robot[1],tmp)
        if tmp == '我想想看...':
            print("當邪惡飛龍的回答是「我想想看...」時，")
            print("邪惡飛龍回想到它原本是邪惡的，所以現在又變成你的敵人而不是朋友。")
            break
        time.sleep(1)
        counter = counter - 1
        
    
print("你在深林裡，遇到一隻邪惡飛龍。")   

while hp > 0:
    
    if '刀子' not in bag2: 
        print("遊戲將要結束，等你的生命值耗盡耗盡中...。")
        print("你剩餘的生命值為：",hp)
    else:
        event1 = input("按下k鍵，表示您想要從背包裡取出刀子：")
        
    if event1 == "k":
        if '刀子' in bag2: 
            print("您已經從背包裡取出刀子，邪惡飛龍被你嚇跑。")
            bag2.remove('刀子')
            exp=exp + 3 
            hp=hp + 1
        else:
            print("您的背包裡沒有刀子，邪惡飛龍咬傷你了！")
            exp=exp + 3 
            hp=hp - 3
            print("你剩餘的生命值為：",hp)
    else: 
        print("邪惡飛龍正飛向你....")
        time.sleep(1.0) 
        print("邪惡飛龍攻擊你。")
        hp=hp - 3 
        time.sleep(2.0) 
        print("但你跟邪惡飛龍說好話，邪惡飛龍變成你的好朋友。")
        time.sleep(3.0) 
        print("邪惡飛龍現在願意幫助你走出深林。")
        exp=exp + 5    
        time.sleep(2.0) 
        converse()
        

if hp <= 0:
    print("**********************************")
    print("你的生命值已耗盡，遊戲結束。")
else:
    print("**********************************")
    print("你剩餘的生命值為：",hp)
    
    
#.............................................







