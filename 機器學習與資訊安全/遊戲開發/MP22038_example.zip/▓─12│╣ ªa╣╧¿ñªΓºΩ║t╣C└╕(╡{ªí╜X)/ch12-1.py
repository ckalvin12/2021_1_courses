
map =[
	[0, 2, 0, 0, 0, 3],
	[0, 0, 0, 1, 0, 0],
	[0, 1, 0, 0, 0, 0],
	[0, 0, 0, 0, 2, 0],
	[0, 2, 0, 1, 0, 0],
	[0, 0, 0, 0, 0, 0]
]

WATER = 0
ISLAND = 1
SNAKE = 2
DESTINATION = 3

ROWS = len(map)
COLUMNS = len(map[0])

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == WATER:
			print("你在湖水裡面。")
		elif map[row][column] == ISLAND:
			print("你登陸一個島上，向村民購買食物。")
		elif map[row][column] == SNAKE:
			print("你遇到湖蛇，湖蛇偷吃你的食物。")
		elif map[row][column] == DESTINATION:
			print("你到達目地的了。")










 