
WATER = 0
ISLAND = 1
SNAKE = 2
HOME = 3
SHIP = 4

map =[
	[WATER, SNAKE, WATER, WATER, WATER, HOME],
	[WATER, WATER, WATER, ISLAND, WATER, WATER],
	[WATER, ISLAND, WATER, WATER, WATER, WATER],
	[WATER, WATER, WATER, WATER, SNAKE, WATER],
	[SNAKE, SNAKE, WATER, ISLAND, WATER, WATER],
	[SHIP, WATER, WATER, WATER, WATER, WATER]
]


UP = 'w'
DOWN = 's'
RIGHT = 'd'
LEFT = 'a'

ROWS = len(map)
COLUMNS = len(map[0])

shipRow = None
shipColumn = None

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == SHIP:
			shipRow = row
			shipColumn = column

def pathcondition():
	if map[shipRow][shipColumn] == WATER:
		print("你在湖水上航行。")
	elif map[shipRow][shipColumn] == SNAKE:
		print("你遇到湖蛇，湖蛇偷吃你的食物。")
	elif map[shipRow][shipColumn] == ISLAND:
		print("你登陸一個島上，向村民購買食物。")
	elif map[shipRow][shipColumn] == HOME:
		print("你到達目地的了。")

while True:

	keydown = input("按下上下左右按鍵(wsda): ")

	if keydown == UP:
		if shipRow > 0:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow -1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif keydown == DOWN:
		if shipRow < ROWS - 1:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow + 1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif keydown == LEFT:
		if shipColumn > 0:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn - 1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif keydown == RIGHT:
		if shipColumn < COLUMNS - 1:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn + 1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

















 