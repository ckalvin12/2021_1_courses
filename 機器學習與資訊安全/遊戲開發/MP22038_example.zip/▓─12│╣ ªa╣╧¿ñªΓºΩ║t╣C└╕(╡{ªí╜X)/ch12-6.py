from random import choice

k = False

WATER = 0
SNAKE = 2
SHIP = 4

map =[
	[0, 0, 0, 0, 0, 0],
	[0, 0, 0, 0, 0, 0],
	[0, 0, 0, 0, 0, 0],
	[0, 0, 0, 2, 0, 0],
	[0, 0, 0, 0, 0, 0],
	[4, 0, 0, 0, 0, 0]
]


UP = 'w'
DOWN = 's'
RIGHT = 'd'
LEFT = 'a'


ROWS = len(map)
COLUMNS = len(map[0])

shipRow = None
shipColumn = None

snakeRow = None
snakeColumn = None

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == SHIP:
			shipRow = row
			shipColumn = column

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == SNAKE:
			snakeRow = row
			snakeColumn = column

def collision():
	if map[shipRow][shipColumn] == map[snakeRow][snakeColumn]:
		print("船撞到水蛇。")
		print("蛇座標：", snakeRow, snakeColumn)
		print("船座標：", shipRow, shipColumn)
		return True

def updatesnake():
	global snakeRow
	global snakeColumn
	map[snakeRow][snakeColumn] = WATER

	if k == False:
		if snakeRow < shipRow:
			snakeRow = snakeRow + 1
		elif snakeRow > shipRow:
			snakeRow = snakeRow - 1
		if snakeColumn < shipColumn:
			snakeColumn = snakeColumn + 1
		elif snakeColumn > shipColumn:
			snakeColumn = snakeColumn - 1
	else:
		if snakeRow < shipRow:
			snakeRow = snakeRow - 1
			if snakeRow < 0:
				snakeRow = ROWS -1
		elif snakeRow > shipRow:
			snakeRow = snakeRow + 1
			if snakeRow > 0:
				snakeRow = 0
		if snakeColumn < shipColumn:
			snakeColumn = snakeColumn - 1
			if snakeColumn < 0:
				snakeColumn = COLUMNS - 1
		elif snakeColumn > shipColumn:
			snakeColumn = snakeColumn + 1
			if snakeColumn > COLUMNS - 1:
				snakeColumn = 0

	map[snakeRow][snakeColumn] = SNAKE
	print("蛇座標：", snakeRow, snakeColumn)

print("蛇座標：", snakeRow, snakeColumn)
print("船座標：",shipRow,shipColumn)

while True:

	keydown = input("按下上下左右按鍵(wsda): ")

	if keydown == UP:
		updatesnake()
		if shipRow > 0:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow -1
			map[shipRow][shipColumn] = SHIP
			if collision():
				break
			print("船座標：",shipRow,shipColumn)
			print("蛇座標：", snakeRow, snakeColumn)
		else:
			print("您已超過地圖上方邊界。")

	elif keydown == DOWN:
		updatesnake()
		if shipRow < ROWS - 1:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow + 1
			# pathcondition()
			map[shipRow][shipColumn] = SHIP
			if collision():
				break
			print("船座標：", shipRow, shipColumn)
			print("蛇座標：", snakeRow, snakeColumn)
		else:
			print("您已超過地圖下方邊界。")

	elif keydown == LEFT:
		updatesnake()
		if shipColumn > 0:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn - 1
			map[shipRow][shipColumn] = SHIP
			if collision():
				break
			print("船座標：", shipRow, shipColumn)
			print("蛇座標：", snakeRow, snakeColumn)
		else:
			print("您已超過地圖左方邊界。")

	elif keydown == RIGHT:
		updatesnake()
		if shipColumn < COLUMNS - 1:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn + 1
			map[shipRow][shipColumn] = SHIP
			if collision():
				break
			print("船座標：", shipRow, shipColumn)
			print("蛇座標：", snakeRow, snakeColumn)
		else:
			print("您已超過地圖右方邊界。")