import time

FOREST = 0
CAVE = 1
FOX = 2
HOME = 3
YOU = 4

map = [
    [0, 2, 0, 0, 0, 3],
    [0, 0, 0, 1, 0, 0],
    [0, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 2, 0],
    [0, 2, 0, 1, 0, 0],
    [4, 0, 0, 0, 0, 0]
]

map2 = [
    [0, 0, 0, 0, 2, 3],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 0, 4]
]


def printmap():
    print("顯示我存在的宇宙世界:")
    for a in map:
        time.sleep(0.2)
        print(a)

def printmap2():
    print("顯示平行宇宙世界:")
    for a in map2:
        time.sleep(0.2)
        print(a)

printmap()
print()
printmap2()

UP = 'w'
DOWN = 's'
RIGHT = 'd'
LEFT = 'a'
PORTAL = 'p'

ROWS = len(map)
COLUMNS = len(map[0])

ROWS2 = len(map2)
COLUMNS2 = len(map2[0])

shipRow = None
shipColumn = None

shipRow2 = None
shipColumn2 = None

for row in range(ROWS):
    for column in range(COLUMNS):
        if map[row][column] == YOU:
            shipRow = row
            shipColumn = column
for row2 in range(ROWS2):
    for column2 in range(COLUMNS2):
        if map2[row2][column2] == YOU:
            shipRow2 = row2
            shipColumn2 = column2

def pathcondition():
    if map[shipRow][shipColumn] == FOREST:
        print("你在深林裡行走。")
    elif map[shipRow][shipColumn] == FOX:
        print("你遇到狐狸，狐狸偷吃你的食物。")
        print("狐狸逃走了！")
    elif map[shipRow][shipColumn] == CAVE:
        print("你進入一個山洞。")
    elif map[shipRow][shipColumn] == HOME:
        print("你到達目地的了。")

def pathcondition2():
    if map2[shipRow2][shipColumn2] == FOREST:
        print("你在深林裡行走。")
    elif map2[shipRow2][shipColumn2] == FOX:
        print("你遇到狐狸，狐狸偷吃你的食物。")
        print("狐狸逃走了！")
    elif map2[shipRow2][shipColumn2] == CAVE:
        print("你進入一個山洞。")
    elif map2[shipRow2][shipColumn2] == HOME:
        print("你到達目地的了。")

while True:
    print()
    keydown = input("按p進入平行宇宙: ")

    if keydown == PORTAL:
        keydown２ = input("按下上下左右按鍵(wsda): ")
        if keydown２ == UP:
            if shipRow2 > 0:
                map2[shipRow2][shipColumn2] = FOREST
                shipRow2 = shipRow2 - 1
                pathcondition2()
                map2[shipRow2][shipColumn2] = YOU
                print(shipRow2, " ", shipColumn2)
                print(map2[shipRow2][shipColumn2])
                printmap2()

        elif keydown２ == DOWN:
            if shipRow2 < ROWS - 1:
                map2[shipRow2][shipColumn2] = FOREST
                shipRow2 = shipRow2 + 1
                pathcondition2()
                map2[shipRow2][shipColumn2] = YOU
                print(shipRow2, " ", shipColumn2)
                print(map2[shipRow2][shipColumn2])
                printmap2()

        elif keydown２ == LEFT:
            if shipColumn2 > 0:
                map2[shipRow2][shipColumn2] = FOREST
                shipColumn2 = shipColumn2 - 1
                pathcondition2()
                map2[shipRow2][shipColumn2] = YOU
                print(shipRow2, " ", shipColumn2)
                print(map2[shipRow2][shipColumn2])
                printmap2()

        elif keydown２ == RIGHT:
            if shipColumn2 < COLUMNS2 - 1:
                map2[shipRow2][shipColumn2] = FOREST
                shipColumn2 = shipColumn2 + 1
                pathcondition2()
                map2[shipRow2][shipColumn2] = YOU
                print(shipRow2, " ", shipColumn2)
                print(map2[shipRow2][shipColumn2])
                printmap2()

    else:

        keydown２ = input("按下上下左右按鍵(wsda): ")
        if keydown２ == UP:
            if shipRow > 0:
                map[shipRow][shipColumn] = FOREST
                shipRow = shipRow - 1
                pathcondition()
                map[shipRow][shipColumn] = YOU
                print(shipRow, " ", shipColumn)
                print(map[shipRow][shipColumn])
                printmap()

        elif keydown２ == DOWN:
            if shipRow < ROWS - 1:
                map[shipRow][shipColumn] = FOREST
                shipRow = shipRow + 1
                pathcondition()
                map[shipRow][shipColumn] = YOU
                print(shipRow, " ", shipColumn)
                print(map[shipRow][shipColumn])
                printmap()

        elif keydown２ == LEFT:
            if shipColumn > 0:
                map[shipRow][shipColumn] = FOREST
                shipColumn = shipColumn - 1
                pathcondition()
                map[shipRow][shipColumn] = YOU
                print(shipRow, " ", shipColumn)
                print(map[shipRow][shipColumn])
                printmap()

        elif keydown２ == RIGHT:
            if shipColumn < COLUMNS - 1:
                map[shipRow][shipColumn] = FOREST
                shipColumn = shipColumn + 1
                pathcondition()
                map[shipRow][shipColumn] = YOU
                print(shipRow, " ", shipColumn)
                print(map[shipRow][shipColumn])
                printmap()

















