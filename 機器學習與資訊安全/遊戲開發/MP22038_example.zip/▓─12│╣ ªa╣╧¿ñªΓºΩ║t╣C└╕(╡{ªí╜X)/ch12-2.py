
map =[
	[0, 2, 0, 0, 0, 3],
	[0, 0, 0, 1, 0, 0],
	[0, 1, 0, 0, 0, 0],
	[0, 0, 0, 0, 2, 0],
	[0, 2, 0, 1, 0, 0],
	[4, 0, 0, 0, 0, 0]
]


WATER = 0
ISLAND = 1
SNAKE = 2
DESTINATION = 3
SHIP = 4

ROWS = len(map)
COLUMNS = len(map[0])

shipRow = None
shipColumn = None

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == SHIP:
			shipRow = row
			shipColumn = column

print("船座標:",shipRow,",",shipColumn)













 