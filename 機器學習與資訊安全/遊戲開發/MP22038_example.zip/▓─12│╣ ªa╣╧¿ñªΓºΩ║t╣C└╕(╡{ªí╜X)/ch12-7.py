FOREST = 0
CAVE = 1
FOX = 2
HOME = 3
YOU = 4

map = [
    [0, 2, 0, 0, 0, 3],
    [0, 0, 0, 1, 0, 0],
    [0, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 2, 0],
    [0, 2, 0, 1, 0, 0],
    [4, 0, 0, 0, 0, 0]
]


def printmap():
    for a in map:
        print(a)


printmap()

UP = 'w'
DOWN = 's'
RIGHT = 'd'
LEFT = 'a'

ROWS = len(map)
COLUMNS = len(map[0])

shipRow = None
shipColumn = None

for row in range(ROWS):
    for column in range(COLUMNS):
        if map[row][column] == YOU:
            shipRow = row
            shipColumn = column


def pathcondition():
    if map[shipRow][shipColumn] == FOREST:
        print("你在深林裡行走。")
    elif map[shipRow][shipColumn] == FOX:
        print("你遇到狐狸，狐狸偷吃你的食物。")
        print("狐狸逃走了！")
    elif map[shipRow][shipColumn] == CAVE:
        print("你進入一個山洞。")
    elif map[shipRow][shipColumn] == HOME:
        print("你到達目地的了。")


while True:

    keydown = input("按下上下左右按鍵(wsda): ")

    if keydown == UP:
        if shipRow > 0:
            map[shipRow][shipColumn] = FOREST
            shipRow = shipRow - 1
            pathcondition()
            map[shipRow][shipColumn] = YOU
            print(shipRow, " ", shipColumn)
            print(map[shipRow][shipColumn])
            printmap()

    elif keydown == DOWN:
        if shipRow < ROWS - 1:
            map[shipRow][shipColumn] = FOREST
            shipRow = shipRow + 1
            pathcondition()
            map[shipRow][shipColumn] = YOU
            print(shipRow, " ", shipColumn)
            print(map[shipRow][shipColumn])
            printmap()

    elif keydown == LEFT:
        if shipColumn > 0:
            map[shipRow][shipColumn] = FOREST
            shipColumn = shipColumn - 1
            pathcondition()
            map[shipRow][shipColumn] = YOU
            print(shipRow, " ", shipColumn)
            print(map[shipRow][shipColumn])
            printmap()

    elif keydown == RIGHT:
        if shipColumn < COLUMNS - 1:
            map[shipRow][shipColumn] = FOREST
            shipColumn = shipColumn + 1
            pathcondition()
            map[shipRow][shipColumn] = YOU
            print(shipRow, " ", shipColumn)
            print(map[shipRow][shipColumn])
            printmap()

















