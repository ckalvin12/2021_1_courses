from random import choice

WATER = 0
ISLAND = 1
SNAKE = 2
Destination = 3
SHIP = 4

map =[
	[0, 2, 0, 0, 0, 3],
	[0, 0, 0, 1, 0, 0],
	[0, 1, 0, 0, 0, 0],
	[0, 0, 0, 0, 2, 0],
	[2, 2, 0, 1, 0, 0],
	[4, 0, 0, 0, 0, 0]
]

map2 =[
	[WATER, SNAKE, WATER, WATER, WATER, Destination],
	[WATER, WATER, WATER, ISLAND, WATER, WATER],
	[WATER, ISLAND, WATER, WATER, WATER, WATER],
	[WATER, WATER, WATER, WATER, SNAKE, WATER],
	[SNAKE, SNAKE, WATER, ISLAND, WATER, WATER],
	[SHIP, WATER, WATER, WATER, WATER, WATER]
]


UP = 'w'
DOWN = 's'
RIGHT = 'd'
LEFT = 'a'

ROWS = len(map)
COLUMNS = len(map[0])

shipRow = None
shipColumn = None

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == SHIP:
			shipRow = row
			shipColumn = column
food = 2

def fight():
	shipenergy = choice(range(1, 10))
	snakeenergy = choice(range(1, 10))
	global food
	if snakeenergy > shipenergy:
		food = food -1
		print("你打輸水蛇，水蛇吃掉你的一部分食物。")
	elif shipenergy > snakeenergy:
		food = food + 1
		print("你打贏水蛇，水蛇的屍體被你當作食物。")

def climb():
	shipenergy = choice(range(1, 10))
	snakeenergy = choice(range(1, 10))
	global food
	if snakeenergy > shipenergy:
		food = food - 5
		print("你打輸食人族，食人族搶走你的一部分食物。")
	elif shipenergy > snakeenergy:
		food = food + 10
		print("你打贏食人族，食人族的食物被你搶走。")

def GameOver():
	print("你到達目地的了。")
	print("你剩餘的食物為:",food)

def pathcondition():
	if map[shipRow][shipColumn] == WATER:
		print("你在湖水上航行。")
	elif map[shipRow][shipColumn] == SNAKE:
		fight()
	elif map[shipRow][shipColumn] == ISLAND:
		climb()
	elif map[shipRow][shipColumn] == Destination:
		GameOver()

while True:

	keydown = input("按下上下左右按鍵(wsda): ")

	if keydown == UP:
		if shipRow > 0:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow -1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif keydown == DOWN:
		if shipRow < ROWS - 1:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow + 1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif keydown == LEFT:
		if shipColumn > 0:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn - 1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif keydown == RIGHT:
		if shipColumn < COLUMNS - 1:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn + 1
			pathcondition()
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

















 