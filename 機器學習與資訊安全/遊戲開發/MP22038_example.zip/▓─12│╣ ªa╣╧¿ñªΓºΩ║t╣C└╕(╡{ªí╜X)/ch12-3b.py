
WATER = 0
SHIP = 4

map =[
	[WATER, WATER, WATER, WATER, WATER, WATER],
	[WATER, WATER, WATER, WATER, WATER, WATER],
	[WATER, WATER, WATER, WATER, WATER, WATER],
	[WATER, WATER, WATER, WATER, WATER, WATER],
	[WATER, WATER, WATER, WATER, WATER, WATER],
	[SHIP, WATER, WATER, WATER, WATER, WATER]
]


UP = 'w'
DOWN = 's'
RIGHT = 'd'
LEFT = 'a'

ROWS = len(map)
COLUMNS = len(map[0])

shipRow = None
shipColumn = None

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == SHIP:
			shipRow = row
			shipColumn = column

while True:

	keydown = input("按下上下左右按鍵(wsda): ")

	if keydown == UP:
		if shipRow > 0:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow -1
			map[shipRow][shipColumn] = SHIP
			print("船座標:",shipRow,",",shipColumn)
			print(map[shipRow][shipColumn])
		else:
			print("船已經在地圖的頂部邊界上！")
			print("船現在不可繼續往上移動！")

	elif keydown == DOWN:
		if shipRow < ROWS - 1:
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow + 1
			map[shipRow][shipColumn] = SHIP
			print("船座標:",shipRow,",",shipColumn)
			print(map[shipRow][shipColumn])
		else:
			print("船已經在地圖的底部邊界上！")
			print("船現在不可繼續往下移動！")

	elif keydown == LEFT:
		if shipColumn > 0:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn - 1
			map[shipRow][shipColumn] = SHIP
			print("船座標:",shipRow,",",shipColumn)
			print(map[shipRow][shipColumn])
		else:
			print("船已經在地圖的左邊界上！")
			print("船現在不可繼續往左移動！")

	elif keydown == RIGHT:
		if shipColumn < COLUMNS - 1:
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn + 1
			map[shipRow][shipColumn] = SHIP
			print("船座標:",shipRow,",",shipColumn)
			print(map[shipRow][shipColumn])
		else:
			print("船已經在地圖的右邊界上！")
			print("船現在不可繼續往右移動！")

















 