from random import choice

WATER = 0
ISLAND = 1
Destination = 3
SHIP = 5

map =[
	[0, 1, 0, 0, 0, 3],
	[0, 0, 0, 1, 0, 0],
	[0, 1, 0, 0, 0, 0],
	[0, 0, 1, 0, 1, 0],
	[0, 1, 5, 1, 0, 0],
	[0, 1, 0, 0, 0, 0]
]

UP = 8
DOWN = 2
RIGHT = 6
LEFT = 4

ROWS = len(map)
COLUMNS = len(map[0])

shipRow = None
shipColumn = None

for row in range(ROWS):
	for column in range(COLUMNS):
		if map[row][column] == SHIP:
			shipRow = row
			shipColumn = column

valid = []
button = [4,6,8,2]
direction = None

while True:
	if shipRow > 0:
		if map[shipRow - 1][shipColumn] == WATER:
			valid.append(8)
	if shipRow < ROWS - 1:
		if map[shipRow + 1][shipColumn] == WATER:
			valid.append(2)
	if shipColumn > 0:
		if map[shipRow][shipColumn - 1] == WATER:
			valid.append(4)
	if shipColumn < COLUMNS - 1:
		if map[shipRow][shipColumn + 1] == WATER:
			valid.append(6)

	if valid != []:
		direction = choice(valid)

	if direction == UP:
		if shipRow > 0:
			print("向上移動")
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow - 1
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif direction == DOWN:
		if shipRow < ROWS - 1:
			print("向下移動")
			map[shipRow][shipColumn] = WATER
			shipRow = shipRow + 1
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif direction == LEFT:
		if shipColumn > 0:
			print("向左移動")
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn - 1
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	elif direction == RIGHT:
		if shipColumn < COLUMNS - 1:
			print("向右移動")
			map[shipRow][shipColumn] = WATER
			shipColumn = shipColumn + 1
			map[shipRow][shipColumn] = SHIP
			print(shipRow, " ", shipColumn)
			print(map[shipRow][shipColumn])

	valid.clear()


















 