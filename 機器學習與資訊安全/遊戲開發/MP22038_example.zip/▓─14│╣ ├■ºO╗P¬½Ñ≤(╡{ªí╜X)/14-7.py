class Car:
    passengers = 0      
    fuelcap = 0         
    mpg  = 0        
    def __init__(self, passengers=1, fuelcap =2, mpg=3):
        self.passengers = passengers
        self.fuelcap = fuelcap
        self.mpg = mpg

class Sportscar(Car):
    brand_name = ""        
    air_bag = 2            
    sunroof = True         
    def __init__(self):
        self.passengers = 1
        self.fuelcap = 2
        self.mpg = 3

    def getDetails(self):
        print("==== Details ====")
        print("passengers:", self.passengers)    
        print("fuelcap:", self.fuelcap)         
        print("mpg:", self.mpg)    

car1 = Sportscar()
car1.getDetails()
if car1.sunroof == True:
    print("It is a good car.")