class Alien:
    def __init__(self, name, hit_point):
        self.name = name
        self. hit_point = hit_point 

total = [Alien("火星人",20),Alien("金星人",30),Alien("天王星人",40)]

sum = 0
for each in total:
    sum = sum + each.hit_point
print("平均殺傷力為: " + str(sum / len(total)))
print("外星人名稱如下所示: ")
for each in total:
   print(each.name)