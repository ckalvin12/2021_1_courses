class Vehicle:
    def __init__(self):
        self.passengers = 10 
        self.fuelcap = 20 
        self.mpg = 30

minivan = Vehicle()
sportscar = Vehicle() 

minivan.passengers = 8
minivan.fuelcap = 50
minivan.mpg = 30

sportscar.passengers = 3
sportscar.fuelcap = 10
sportscar.mpg = 15

range1 = minivan.fuelcap * minivan.mpg;
range2 = sportscar.fuelcap * sportscar.mpg;
print("Minivan can carry ",minivan.passengers," with a range of ",range1)
print("Sportscar can carry ",sportscar.passengers," with a range of ",range2)

