class Vehicle:
    def __init__(self):
        self.passengers = 10 
        self.fuelcap = 20 
        self.mpg = 30

minivan = Vehicle() 

range = minivan.fuelcap * minivan.mpg
print("Minivan can carry ", minivan.passengers ," with a range of ",range )

minivan.mpg = 100

print(minivan.mpg)
