class Alien:
    hit_point = 20
    name = "天王星人"    
      
total = [Alien(), Alien()]
sum = 0
for each in total:
    sum = sum + each.hit_point
print(total[0].name+"的平均殺傷力為: " + str(sum / len(total)))