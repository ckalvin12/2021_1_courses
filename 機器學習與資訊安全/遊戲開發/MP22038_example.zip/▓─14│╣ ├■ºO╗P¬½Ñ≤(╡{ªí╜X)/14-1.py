import random

class Coin:
  def __init__(self):
    self.sideup = '正面朝上'
  def toss(self):
    if random.randint(0, 1) == 1:
      self.sideup = '正面朝上'
    else:
      self.sideup = '反面朝上'
  def get_sideup(self):
    return self.sideup

my_coin = Coin()
print(my_coin.get_sideup())
print('拋硬幣中...')
my_coin.toss()
print(my_coin.get_sideup())