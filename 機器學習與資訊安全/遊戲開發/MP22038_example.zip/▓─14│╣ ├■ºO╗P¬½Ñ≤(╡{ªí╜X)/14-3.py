class Alien:
    hit_point = 20
    name = "天王星人"    
total = [Alien(),Alien(), Alien()]
total[0].name = "火星人"  
total[0].hit_point = 20
total[1].name = "金星人"  
total[1].hit_point = 30
total[2].name = "天王星人"  
total[2].hit_point = 40

sum = 0
for each in total:
    sum = sum + each.hit_point
print("平均殺傷力為: " + str(sum / len(total)))
print("外星人名稱如下所示: ")
for each in total:
   print(each.name)