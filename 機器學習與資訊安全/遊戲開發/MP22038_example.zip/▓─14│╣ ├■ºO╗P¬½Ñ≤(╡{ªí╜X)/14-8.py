class Car:
    passengers = 0     
    fuelcap = 0         
    mpg  = 0        
    def __init__(self, passengers=1, fuelcap =2, mpg=3):
        self.passengers = passengers
        self.fuelcap = fuelcap
        self.mpg = mpg
        
    def drive(self):
        print("")

class Sportscar(Car):
    brand_name = ""        
    air_bag = 2            
    sunroof = True         
    def __init__(self,brand_name):
        self.passengers = 1
        self.fuelcap = 20
        self.mpg = 3000
        self.brand_name = brand_name

    def getDetails(self):
        print("==== Details ====")
        print("passengers:", self.passengers)    
        print("fuelcap:", self.fuelcap)         
        print("mpg:", self.mpg)
        
    def drive(self):
        print("I have this",self.brand_name)

class Truck(Car):
    brand_name = ""        
    air_bag = 2            
    sunroof = True         
    def __init__(self,brand_name):
        self.passengers = 10
        self.fuelcap = 30
        self.mpg = 200
        self.brand_name = brand_name

    def getDetails(self):
        print("==== Details ====")
        print("passengers:", self.passengers)    
        print("fuelcap:", self.fuelcap)         
        print("mpg:", self.mpg)
        
    def drive(self):
        print("I have this",self.brand_name)
        print("The number of passengers are:",self.passengers)
          

car1 = Sportscar("Speedy Model")
car1.getDetails()

car2 = Truck("Big Model")
car2.getDetails()

def select(cars):
    for car in cars:
        print()
        car.drive()
 
select([car1,car2])
