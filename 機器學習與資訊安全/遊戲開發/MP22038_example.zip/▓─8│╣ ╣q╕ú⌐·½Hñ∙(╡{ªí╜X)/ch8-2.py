from os import system

p = input("您在哪裡？")
d = input("您們玩的如何？")
w = input("天氣如何？")
f = input("還有食物好吃嗎？")
n = input("您叫什麼名字？")
t = input("您在寫信給誰？")

system('cls') 

print("親愛的 "+t+",")
print("我們在"+p+"玩的"+d+"。")
print("天氣"+w+",")
print("還有食物"+f+"。")
print("希望您能來加入我們！")
print("來自"+n+"的邀請！")



