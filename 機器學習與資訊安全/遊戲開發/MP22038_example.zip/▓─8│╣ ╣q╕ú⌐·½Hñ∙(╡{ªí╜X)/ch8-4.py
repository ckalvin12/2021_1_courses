import random

nouns = ("我", "湯姆", "蟒蛇", "你", "烏龜")
verbs = ("吃", "喜歡", "討厭", "看見", "爬")
objects = ("食物.", "蟒蛇.", "辣椒.", "烏龜.", "樹.")
num = random.randrange(0,5)
print(nouns[num] + verbs[num] + objects[num])



