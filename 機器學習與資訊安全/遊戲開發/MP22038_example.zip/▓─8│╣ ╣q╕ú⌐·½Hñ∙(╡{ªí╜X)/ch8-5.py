from os import system
import random

p = ("台中", "高雄", "台北")
d = ("很高興", "很可惜", "不好玩")
w = ("很熱", "很冷", "很舒適")
f = ("很好吃", "很難吃", "很甜")
n = ("小明", "大雄", "小甜甜")
t = ("大同", "小豬", "小英")

num = random.randrange(0,3)

print("親愛的 "+t[num]+",")
print("我們在"+p[num]+"玩的"+d[num]+"。")
print("天氣"+w[num]+",")
print("還有食物"+f[num]+"。")
print("希望您能來加入我們！")
print("來自"+n[num]+"的邀請！")



