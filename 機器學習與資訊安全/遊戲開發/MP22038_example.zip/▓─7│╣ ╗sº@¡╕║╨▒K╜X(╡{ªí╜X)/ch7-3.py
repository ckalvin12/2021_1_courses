import random

print('''      
      _.---._    
    .'  O  O  '.      
 _.-~===========~-._  
(__________________) 
     \_______/  
               ''')
print()
print("飛碟密碼")
print()
print("請先輸入一個小寫字母，然後輸入一個大寫字母")
print("以解除飛碟自爆機制。")
print("您只有3次機會")
print()

def guess_letter():
    return random.choice('abcdefghijklmnopqrstuvwxyz')

first_letter = guess_letter()
#print(first_letter)

def guess_letter2():
    return random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
	
second_letter = guess_letter2()
#print(second_letter)

no_explosion = False

def fun1():
	print("已解除飛碟自爆機制，你拯救了地球人。")
	

for x in range(3):
	fg = input("first_letter: ")
	fg2 = input("second_letter: ")
	
	if fg2.islower():
		fg2 = chr(ord(fg2) - 32)  
	
	if fg == first_letter and fg2 == second_letter:
		fun1()
		no_explosion = True	
		break
	if fg < first_letter:
		print("字母還在後面")
	if fg > first_letter:
		print("字母還在前面")

if no_explosion == True:
	pass
else:
	print('''
			  _ ._  _ , _ ._
			(_ ' ( `  )_  .__)
		  ( (  (    )   `)  ) _)
		 (__ (_   (_ . _) _) ,__)
			 `~~`\ ' . /`~~`
		''')
	
	print("			地球爆炸了！")

		





