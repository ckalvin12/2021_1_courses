import random

print('''      
      _.---._    
    .'  O  O  '.      
 _.-~===========~-._  
(__________________) 
     \_______/  
               ''')
print()
print("請輸入一個小寫字母")
print("以解除飛碟自爆機制。")
print("您只有3次機會。")
print("如果你輸入錯誤的小寫字母，飛碟爆炸威力將會摧毀地球！")
print()

def guess_letter():
    return random.choice('abcdefghijklmnopqrstuvwxyz')

first_letter = guess_letter()
#print(first_letter)

no_explosion = False

def fun1():
	print("已解除飛碟自爆機制，你拯救了地球人。")
	

for x in range(3):
	fg = input("first_letter: ")
	
	if fg == first_letter:
		fun1()
		no_explosion = True	
		break
	if fg < first_letter:
		print("字母還在後面")
	if fg > first_letter:
		print("字母還在前面")

if no_explosion == True:
	pass
else:
	print('''
			  _ ._  _ , _ ._
			(_ ' ( `  )_  .__)
		  ( (  (    )   `)  ) _)
		 (__ (_   (_ . _) _) ,__)
			 `~~`\ ' . /`~~`
		''')
	
	print("			地球爆炸了！")

		





