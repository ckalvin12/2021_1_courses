from random import choice

word = choice(["apple","eat","milk","drink"])

print("電腦會隨機從這4個英文字[apple,eat,milk,drink]中，挑選一個。")
print("請注意英文字的長度將用破折號表示！")

#print(word)

out = ""

for letter in word:
    out = out + "_ "

print("請依據破折號的暗示來猜一個字母:", out)

guess = input("請輸入一個字母: ")

if guess in word:
    print("猜中了")
else:
    print("猜錯了")
	
